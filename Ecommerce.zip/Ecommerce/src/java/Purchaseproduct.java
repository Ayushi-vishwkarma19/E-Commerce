

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Purchaseproduct extends HttpServlet {

  
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       try{
           PrintWriter out=response.getWriter();
             String s1=request.getParameter("pcode");
             String s2=request.getParameter("pname");
             String s3=request.getParameter("pdesc");
             String s4=request.getParameter("pcat");
                  
        String code =request.getParameter("code");
        String sql="Select price from products where pcode=?";
        try{
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ecomdata?allowPublicKeyRetrieval=true&useSSL=false", "root", "root");
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setInt(1,Integer.parseInt(code));
                    ResultSet rs=ps.executeQuery();
                     out.println("<html>");
                     out.println("  <body background=\"image\\image4.jpg\"\n" +
"          style=\"background-repeat:no-repeat;background-size:100%100%\">");
                     out.println("<h3> Purchase-Product</h3>");
                     out.println("<hr>");
                     out.println("<form action=Makepayment.jsp>");
                     rs.next();
                     String s5=rs.getString(1);//price
                     
                     out.println("<table border =2>");
                     out.println("<tr>");
                     out.println("<td>code</td>");
                     out.println("<td><input type = text name = "+s1+"/></td>");
                     //out.println("</tr>");
                     out.println("<tr>");
                     out.println("<td>name</td>");
                     out.println("<td><input type = text name = "+s2+"/></td>");
                    // out.println("/tr");
                    
                    // out.println("/tr");
                     
                     
                     //out.println("/tr");
                     out.println("<tr>");
                     out.println("<td>Price</td>");
                     out.println("<td>"+s5+"</td>");
                     out.println("<tr>");
                     out.println("<td><input type=submit value=PURCHASE /></td>");
                     out.println("<td><input type=reset value=RESET /></td>");
                     //out.println("/tr");
                     out.println("</table>");
                     out.println("</form>");
                     out.println("<hr>");
                     out.println("<a href =Categorypage>Categories</a><br>");
                     out.println("<a href=buyerpage.jsp>BuyerPage</a><br>");
                     out.println("</body>");
                     out.println("</html>");
                     con.close();
                    }catch(Exception e){
                    out.println(e);
               }
       
        }catch(Exception e){
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
